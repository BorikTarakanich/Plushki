<?php get_template_part( 'apiInstagram/getDataInst' );
$linkInstDataFirst=$GLOBALS["linkInstDataFirst"];
$linkInstDataSecond=$GLOBALS["linkInstDataSecond"];

?>


<div class="col-md-6 hidden-sm hidden-xs">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			
<noindex>
<blockquote class="instagram-media" style="background: #FFF; border: 0; border-radius: 3px; box-shadow: 0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width: 540px; width:100%; min-width: 326px; padding: 0; width: calc(100% - 2px);" data-instgrm-captioned="" data-instgrm-permalink="<?php echo $linkInstDataFirst; ?>?utm_source=ig_embed" data-instgrm-version="9">
</blockquote>
<script async="" defer="" src="//www.instagram.com/embed.js"></script>

</noindex>

		</div>
	</div>
</div><div class="col-md-6">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
	
<noindex>
<blockquote class="instagram-media" style="background: #FFF; border: 0; border-radius: 3px; box-shadow: 0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width: 540px; min-width: 326px; padding: 0; width: calc(100% - 2px);" data-instgrm-captioned="" data-instgrm-permalink="<?php echo $linkInstDataSecond; ?>?utm_source=ig_embed" data-instgrm-version="9">
</blockquote>
<script async="" defer="" src="//www.instagram.com/embed.js"></script>

</noindex>		
		</div>
	</div>
</div>