async function postData() {
  let urlIn = decodeURI("https://cdis.russvet.ru/rs/position/96/instock");

  function b64EncodeUnicode(str) {
    // first we use encodeURIComponent to get percent-encoded UTF-8,https://cdis.russvet.ru/rs/price/528241
    // then we convert the percent encodings into raw bytes which
    // can be fed into btoa.
    return btoa(
      encodeURIComponent(str).replace(
        /%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
          return String.fromCharCode("0x" + p1);
        }
      )
    );
  }

  let api_user = "U0tTXzIwMTg=";
  let api_pass = "RTQ5MTA2M0w=";
  userAndPass = b64EncodeUnicode(String(api_user, api_pass));
  headers = {
    "Content-Type": "application/json",
    Authorization: "Basic " + api_user + ":" + api_pass,
  };

  const response = await fetch("https://cdis.russvet.ru/rs/position", {
    method: "GET",
    mode: "no-cors",
    headers: headers,
  })
    .then((res) => console.log(res))
    .then((resp) => console.log(resp));

  function b64DecodeUnicode(str) {
    // Going backwards: from bytestream, to percent-encoding, to original string.
    return decodeURIComponent(
      atob(str)
        .split("")
        .map(function (c) {
          return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
  }

  return response;
}
postData();
// userAndPass = b64encode("{0}:{1}".format(api_user, api_pass).encode("utf-8"));
// headers = {
//   "Content-Type": "application/json",
//   Authorization: "Basic" + userAndPass.decode("utf-8"),
// };
