// class Curc {
//   constructor() {
//     this.cursURL = "https://www.nbrb.by/api/exrates/rates?periodicity=0";
//     this.PositionValute = 16;
//     this.oldCurs = 3.525;
//     this.newCurs;
//   }
//   async getCurs() {
//     try {
//       const resp = await fetch(this.cursURL)
//         .then((resJSON) => resJSON.json())
//         .then((resPos) =>
//           this.abr(
//             resPos[this.PositionValute].Cur_OfficialRate,
//             resPos[this.PositionValute].Cur_Abbreviation
//           )
//         )
//         .then((res) => (this.newCurs = res));
//     } catch {
//       this.newCurs = this.oldCurs;
//     }

//     return this.newCurs;
//   }

//   abr(curs, abr) {
//     console.log(curs);
//     console.log(abr);
//     if (abr == "RUB") {
//       return curs;
//     } else return;
//   }
// }
// let newCurs = new Curc();
// newCurs.getCurs().then((res) => myfun(res));

// function myfun(curs) {
//   let data = {
//     curs: curs,
//   };
//   console.log(data);
// }
