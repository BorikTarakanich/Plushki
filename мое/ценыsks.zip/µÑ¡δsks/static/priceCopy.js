// async function postData() {
//   let urlIn = "https://cdis.russvet.ru/rs/price/1403229";
//   let username = "SKS_2018";
//   let password = "E491063L";
//   let headers = new Headers();

//   headers.set("Authorization", "Basic" + username + ":" + password);

//   const response = await fetch(urlIn, {
//     method: "GET",
//     mode: "no-cors",
//     headers: headers,
//   })
//     .then((res) => res.json())
//     .then((resp) => resp);

//   console.log(response);
//   return response;
// }

// postData().then((res) => console.log(res));

// const getCurs = async () => {
//   let CurAbbreviation = "RUB";
//   await fetch("https://www.nbrb.by/api/exrates/rates?periodicity=0")
//     .then((res) => res.json())
//     .then((resp) => myfun(resp.Cur_OfficialRate));
// };

// getCurs();

// function myfun(curs) {
//   let data = {
//     curs: curs,
//   };
//   console.log(data);
// }
